import { createHash, timingSafeEqual } from 'node:crypto';
import { Client, Account, Users, Teams, TablesDB, ID, Query } from 'node-appwrite';

const DATABASE_ID = 'default';
const APPLICATIONS_TABLE_ID = 'betaApplications';
const BETA_TEAM_ID = 'beta-members';
const MAX_REASON = 4000;
const MAX_FEATURES = 2000;
const PUSH_WORKER = 'https://chatbykarnav-push.karnavgandhi21.workers.dev/';
async function notify(uid, title, message) {
  if (!uid) return;
  try {
    await fetch(PUSH_WORKER, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ targetUid: uid, title, body: message }) });
  } catch (_) { /* Notifications are best-effort; never fail a beta application/review. */ }
}

function parseBody(req) {
  if (typeof req.body === 'string') return JSON.parse(req.body || '{}');
  return req.body || req.bodyJson || {};
}
function json(res, status, payload) {
  return res.json(payload, status);
}
function cleanText(value, max) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

export default async ({ req, res, log, error }) => {
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'Use POST.' });
  let body;
  try { body = parseBody(req); }
  catch { return json(res, 400, { ok: false, error: 'Request body must be valid JSON.' }); }

  const action = cleanText(body.action, 40);
  const isAdminAction = action.startsWith('admin.');
  const serverKey = req.headers?.['x-appwrite-key'];
  const endpoint = process.env.APPWRITE_FUNCTION_API_ENDPOINT;
  const projectId = process.env.APPWRITE_FUNCTION_PROJECT_ID;
  if (!serverKey || !endpoint || !projectId) {
    error('Missing Appwrite runtime credentials.');
    return json(res, 503, { ok: false, error: 'Beta service is not configured.' });
  }

  try {
    const adminClient = new Client().setEndpoint(endpoint).setProject(projectId).setKey(serverKey);
    const users = new Users(adminClient);
    const teams = new Teams(adminClient);
    const tables = new TablesDB(adminClient);
    let currentUser = null;

    if (isAdminAction) {
      const expectedHash = process.env.ADMIN_PASSCODE_SHA256 || '';
      const supplied = typeof body.adminPasscode === 'string' ? body.adminPasscode : '';
      const suppliedHash = createHash('sha256').update(supplied).digest('hex');
      if (!expectedHash || suppliedHash.length !== expectedHash.length || !timingSafeEqual(Buffer.from(suppliedHash), Buffer.from(expectedHash))) {
        return json(res, 401, { ok: false, error: 'Incorrect administrator passcode.' });
      }
    } else {
      const jwt = typeof body.userJwt === 'string' ? body.userJwt : req.headers?.['x-appwrite-user-jwt'];
      if (!jwt) return json(res, 401, { ok: false, error: 'Sign in to your ChatByKarnav account first.' });
      const userClient = new Client().setEndpoint(endpoint).setProject(projectId).setJWT(jwt);
      currentUser = await new Account(userClient).get();
    }

    const findApplication = async (uid) => {
      const found = await tables.listRows({
        databaseId: DATABASE_ID,
        tableId: APPLICATIONS_TABLE_ID,
        queries: [Query.equal('uid', [uid]), Query.limit(1)]
      });
      return found.rows?.[0] || null;
    };

    if (action === 'apply') {
      const displayName = cleanText(body.displayName || currentUser.name || 'Member', 40) || 'Member';
      const reason = cleanText(body.reason, MAX_REASON);
      const features = cleanText(body.features, MAX_FEATURES);
      if (reason.length < 10) return json(res, 400, { ok: false, error: 'Please provide at least 10 characters explaining why you want beta access.' });
      const existing = await findApplication(currentUser.$id);
      if (existing?.status === 'approved') return json(res, 200, { ok: true, status: 'approved', message: 'Your account already has beta access.' });
      if (existing?.status === 'pending') return json(res, 200, { ok: true, status: 'pending', message: 'Your application is already awaiting review.' });
      if (existing?.status === 'suspended') return json(res, 403, { ok: false, status: 'suspended', error: 'This account is suspended from the beta.' });
      const data = { uid: currentUser.$id, displayName, reason, features, status: 'pending', appliedAt: new Date().toISOString(), reviewedAt: null, reviewedBy: null, adminNote: '' };
      const row = existing
        ? await tables.updateRow({ databaseId: DATABASE_ID, tableId: APPLICATIONS_TABLE_ID, rowId: existing.$id, data })
        : await tables.createRow({ databaseId: DATABASE_ID, tableId: APPLICATIONS_TABLE_ID, rowId: ID.unique(), data });
      log(`Beta application submitted by ${currentUser.$id}.`);
      const adminNotifyUid = process.env.ADMIN_NOTIFY_USER_ID || '';
      if (adminNotifyUid) await notify(adminNotifyUid, 'New beta application', `${displayName} submitted a ChatByKarnav beta application.`);
      return json(res, 200, { ok: true, status: row.status, message: 'Application submitted. An administrator will review it.' });
    }

    if (action === 'status') {
      const row = await findApplication(currentUser.$id);
      return json(res, 200, { ok: true, status: row?.status || 'not_applied', application: row ? { displayName: row.displayName, appliedAt: row.appliedAt, reviewedAt: row.reviewedAt, adminNote: row.adminNote || '' } : null });
    }

    const FEATURE_CATALOG = [
      { id: 'message-edit-delete', title: 'Message editing & deletion', description: 'Improve editing, undo and delete controls.' },
      { id: 'message-reactions', title: 'Message reactions', description: 'More emoji reactions and reaction details.' },
      { id: 'group-polls', title: 'Group polls', description: 'Create polls and vote inside group chats.' },
      { id: 'voice-messages', title: 'Voice messages', description: 'Record and send short voice notes.' },
      { id: 'advanced-search', title: 'Advanced search', description: 'Find messages, people and shared files.' },
      { id: 'typing-indicators', title: 'Typing indicators', description: 'See when other members are typing.' },
      { id: 'online-presence', title: 'Online status', description: 'See who is online and when they were last active.' },
      { id: 'beta-feedback', title: 'Beta feedback', description: 'Send feedback and report bugs.' },
      { id: 'feature-voting', title: 'Feature voting', description: 'Vote for the features you want next.' },
      { id: 'whats-new', title: 'What’s New', description: 'See new beta releases and improvements.' }
    ];

    if (action === 'feature.list') {
      const result = await tables.listRows({
        databaseId: DATABASE_ID, tableId: 'bugReports',
        queries: [Query.equal('severity', ['idea']), Query.equal('status', ['vote']), Query.limit(500)]
      });
      const rows = result.rows || [];
      const features = FEATURE_CATALOG.map(feature => ({
        ...feature,
        votes: rows.filter(row => row.title === feature.id).length,
        votedByMe: rows.some(row => row.title === feature.id && row.uid === currentUser.$id)
      })).sort((a, b) => b.votes - a.votes || a.title.localeCompare(b.title));
      return json(res, 200, { ok: true, features });
    }

    if (action === 'feature.vote') {
      const featureId = cleanText(body.featureId, 40);
      const feature = FEATURE_CATALOG.find(item => item.id === featureId);
      if (!feature) return json(res, 400, { ok: false, error: 'Choose a valid beta feature.' });
      const found = await tables.listRows({
        databaseId: DATABASE_ID, tableId: 'bugReports',
        queries: [Query.equal('uid', [currentUser.$id]), Query.equal('title', [feature.id]), Query.equal('severity', ['idea']), Query.limit(1)]
      });
      const existing = found.rows?.[0] || null;
      let voted;
      if (existing?.status === 'vote') {
        await tables.updateRow({ databaseId: DATABASE_ID, tableId: 'bugReports', rowId: existing.$id, data: { status: 'withdrawn' } });
        voted = false;
      } else if (existing) {
        await tables.updateRow({ databaseId: DATABASE_ID, tableId: 'bugReports', rowId: existing.$id, data: { status: 'vote', description: feature.description } });
        voted = true;
      } else {
        await tables.createRow({
          databaseId: DATABASE_ID, tableId: 'bugReports', rowId: ID.unique(),
          data: { uid: currentUser.$id, displayName: cleanText(currentUser.name || 'Member', 40) || 'Member', title: feature.id, description: feature.description, severity: 'idea', status: 'vote', createdAt: new Date().toISOString(), adminNote: '' }
        });
        voted = true;
      }
      const result = await tables.listRows({ databaseId: DATABASE_ID, tableId: 'bugReports', queries: [Query.equal('title', [feature.id]), Query.equal('severity', ['idea']), Query.equal('status', ['vote']), Query.limit(500)] });
      return json(res, 200, { ok: true, featureId, voted, votes: (result.rows || []).length });
    }

    if (action === 'bug.submit') {
      const title = cleanText(body.title, 160);
      const description = cleanText(body.description, 5000);
      const severity = cleanText(body.severity, 20);
      if (title.length < 4) return json(res, 400, { ok: false, error: 'Please enter a bug title of at least 4 characters.' });
      if (description.length < 10) return json(res, 400, { ok: false, error: 'Please describe the bug in at least 10 characters.' });
      if (!['low', 'normal', 'high', 'critical'].includes(severity)) return json(res, 400, { ok: false, error: 'Choose a valid severity.' });
      const report = await tables.createRow({
        databaseId: DATABASE_ID, tableId: 'bugReports', rowId: ID.unique(),
        data: { uid: currentUser.$id, displayName: cleanText(currentUser.name || 'Member', 40) || 'Member', title, description, severity, status: 'open', createdAt: new Date().toISOString(), adminNote: '' }
      });
      log(`Bug report ${report.$id} submitted by ${currentUser.$id}.`);
      return json(res, 200, { ok: true, message: 'Bug report sent. Thank you for helping improve ChatByKarnav.', reportId: report.$id });
    }

    if (action === 'admin.bugs.list') {
      const status = cleanText(body.status, 20);
      const queries = [Query.orderDesc('createdAt'), Query.limit(Math.min(Math.max(Number(body.limit) || 100, 1), 200))];
      if (['open', 'in_progress', 'resolved', 'closed'].includes(status)) queries.unshift(Query.equal('status', [status]));
      const result = await tables.listRows({ databaseId: DATABASE_ID, tableId: 'bugReports', queries });
      return json(res, 200, { ok: true, rows: result.rows || [], total: result.total || 0 });
    }

    if (action === 'admin.bugs.update') {
      const rowId = cleanText(body.rowId, 36);
      const status = cleanText(body.status, 20);
      const adminNote = cleanText(body.adminNote, 4000);
      if (!rowId || !['open', 'in_progress', 'resolved', 'closed'].includes(status)) return json(res, 400, { ok: false, error: 'A valid bug report and status are required.' });
      const updated = await tables.updateRow({ databaseId: DATABASE_ID, tableId: 'bugReports', rowId, data: { status, adminNote } });
      log(`Admin updated bug report ${rowId} to ${status}.`);
      return json(res, 200, { ok: true, report: updated });
    }

    if (action === 'admin.users.list') {
      const search = cleanText(body.search, 256);
      const limit = Math.min(Math.max(Number(body.limit) || 50, 1), 100);
      const offset = Math.max(Number(body.offset) || 0, 0);
      const result = await users.list({
        queries: [Query.orderDesc('$createdAt'), Query.limit(limit), Query.offset(offset)],
        ...(search ? { search } : {})
      });
      const safeUsers = (result.users || []).map(u => ({
        $id: u.$id, name: u.name || '', email: u.email || '', phone: u.phone || '',
        status: !!u.status, emailVerification: !!u.emailVerification,
        registration: u.registration || '', accessedAt: u.accessedAt || '',
        labels: Array.isArray(u.labels) ? u.labels : [], mfa: !!u.mfa
      }));
      return json(res, 200, { ok: true, users: safeUsers, total: result.total || 0 });
    }

    if (action === 'admin.user.update') {
      const userId = cleanText(body.userId, 36);
      if (!userId) return json(res, 400, { ok: false, error: 'A valid user ID is required.' });
      const protectedIds = (process.env.ADMIN_USER_IDS || '').split(',').map(x => x.trim()).filter(Boolean);
      if (protectedIds.includes(userId)) return json(res, 403, { ok: false, error: 'The primary administrator account is protected from changes here.' });
      let updated = await users.get(userId);
      if (typeof body.name === 'string') updated = await users.updateName({ userId, name: cleanText(body.name, 128) });
      if (typeof body.email === 'string' && body.email.trim()) updated = await users.updateEmail({ userId, email: cleanText(body.email, 320) });
      if (typeof body.status === 'boolean') updated = await users.updateStatus({ userId, status: body.status });
      if (typeof body.emailVerification === 'boolean') updated = await users.updateEmailVerification({ userId, emailVerification: body.emailVerification });
      return json(res, 200, { ok: true, user: { $id: updated.$id, name: updated.name || '', email: updated.email || '', status: !!updated.status, emailVerification: !!updated.emailVerification } });
    }

    if (action === 'admin.user.recovery') {
      const userId = cleanText(body.userId, 36);
      if (!userId) return json(res, 400, { ok: false, error: 'A valid user ID is required.' });
      const target = await users.get(userId);
      if (!target.email) return json(res, 400, { ok: false, error: 'This account does not have an email address.' });
      const recovery = await fetch(`${endpoint}/account/recovery`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Appwrite-Project': projectId },
        body: JSON.stringify({ email: target.email, url: 'https://chatbykarnav.github.io/reset-password/' })
      });
      const result = await recovery.json().catch(() => ({}));
      if (!recovery.ok) return json(res, recovery.status, { ok: false, error: result.message || 'Could not send the password reset code.' });
      log(`Admin sent a password recovery code to user ${userId}.`);
      return json(res, 200, { ok: true, message: 'Password reset code sent to the account email.', userId: result.userId || userId });
    }

    if (action === 'admin.user.delete') {
      const userId = cleanText(body.userId, 36);
      const confirmation = cleanText(body.confirmUserId, 36);
      if (!userId || confirmation !== userId) return json(res, 400, { ok: false, error: 'Type the exact account ID to confirm deletion.' });
      const protectedIds = (process.env.ADMIN_USER_IDS || '').split(',').map(x => x.trim()).filter(Boolean);
      if (protectedIds.includes(userId)) return json(res, 403, { ok: false, error: 'The primary administrator account cannot be deleted here.' });
      const target = await users.get(userId);
      const memberships = await teams.listMemberships({ teamId: BETA_TEAM_ID, queries: [Query.limit(100)] }).catch(() => ({ memberships: [] }));
      for (const membership of (memberships.memberships || []).filter(m => m.userId === userId)) {
        await teams.deleteMembership({ teamId: BETA_TEAM_ID, membershipId: membership.$id }).catch(() => {});
      }
      const application = await findApplication(userId).catch(() => null);
      if (application) await tables.deleteRow({ databaseId: DATABASE_ID, tableId: APPLICATIONS_TABLE_ID, rowId: application.$id }).catch(() => {});
      await tables.deleteRow({ databaseId: DATABASE_ID, tableId: 'publicProfiles', rowId: userId }).catch(() => {});
      const statuses = await tables.listRows({ databaseId: DATABASE_ID, tableId: 'statuses', queries: [Query.equal('uid', [userId]), Query.limit(100)] }).catch(() => ({ rows: [] }));
      for (const row of (statuses.rows || [])) await tables.deleteRow({ databaseId: DATABASE_ID, tableId: 'statuses', rowId: row.$id }).catch(() => {});
      await users.delete(userId);
      log(`Admin deleted account ${userId} (${target.email || 'no email'}).`);
      return json(res, 200, { ok: true, message: 'Account deleted. Shared chat history and uploaded files were retained.' });
    }

    if (action === 'admin.list') {
      const status = cleanText(body.status, 20);
      const queries = [Query.orderDesc('appliedAt'), Query.limit(Math.min(Math.max(Number(body.limit) || 100, 1), 200))];
      if (['pending', 'approved', 'rejected', 'suspended'].includes(status)) queries.unshift(Query.equal('status', [status]));
      const result = await tables.listRows({ databaseId: DATABASE_ID, tableId: APPLICATIONS_TABLE_ID, queries });
      return json(res, 200, { ok: true, rows: result.rows || [], total: result.total || 0 });
    }

    if (action === 'admin.review') {
      const rowId = cleanText(body.rowId, 36);
      const status = cleanText(body.status, 20);
      const adminNote = cleanText(body.adminNote, 4000);
      if (!rowId || !['approved', 'rejected', 'suspended'].includes(status)) return json(res, 400, { ok: false, error: 'A valid application and review status are required.' });
      const row = await tables.getRow({ databaseId: DATABASE_ID, tableId: APPLICATIONS_TABLE_ID, rowId });
      await users.get(row.uid);
      const updated = await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: APPLICATIONS_TABLE_ID,
        rowId,
        data: { status, reviewedAt: new Date().toISOString(), reviewedBy: 'admin-passcode', adminNote }
      });
      const memberships = await teams.listMemberships({ teamId: BETA_TEAM_ID, queries: [Query.limit(100)] });
      const membership = (memberships.memberships || []).find(m => m.userId === row.uid);
      if (status === 'approved' && !membership) {
        await teams.createMembership({ teamId: BETA_TEAM_ID, roles: ['member'], userId: row.uid, name: row.displayName || 'Beta member' });
      } else if (status !== 'approved' && membership) {
        await teams.deleteMembership({ teamId: BETA_TEAM_ID, membershipId: membership.$id });
      }
      log(`Admin passcode authenticated a review of beta application ${rowId} to ${status}.`);
      await notify(row.uid, `Beta application ${status}`, status === 'approved' ? 'Your ChatByKarnav beta access has been approved.' : status === 'suspended' ? 'Your ChatByKarnav beta access has been suspended.' : 'Your ChatByKarnav beta application was not approved. You may reapply later.');
      return json(res, 200, { ok: true, application: updated, betaTeamUpdated: true });
    }

    if (action === 'admin.stats') {
      const result = await tables.listRows({ databaseId: DATABASE_ID, tableId: APPLICATIONS_TABLE_ID, queries: [Query.limit(200)] });
      const rows = result.rows || [];
      return json(res, 200, { ok: true, total: result.total || rows.length, pending: rows.filter(r => r.status === 'pending').length, approved: rows.filter(r => r.status === 'approved').length, rejected: rows.filter(r => r.status === 'rejected').length, suspended: rows.filter(r => r.status === 'suspended').length });
    }

    return json(res, 400, { ok: false, error: 'Unknown action.' });
  } catch (err) {
    error(`Beta API error: ${err?.message || String(err)}`);
    const code = Number(err?.code) || 500;
    return json(res, code >= 400 && code < 600 ? code : 500, { ok: false, error: code === 404 ? 'Application not found.' : 'The beta request could not be completed.' });
  }
};
